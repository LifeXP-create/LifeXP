import React, { useEffect, useState } from "react";
import { Redirect, useRouter } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ActivityIndicator, View } from "react-native";

export default function Index(){
  const [ready,setReady]=useState(false);
  const [onb,setOnb]=useState(false);
  const router=useRouter();

  useEffect(()=>{(async()=>{
    const flag = await AsyncStorage.getItem("lifexp_onboarded_v1");
    setOnb(flag==="1"); setReady(true);
  })()},[]);

  if(!ready) return <View style={{flex:1,justifyContent:"center"}}><ActivityIndicator/></View>;
  return onb ? <Redirect href="/quests" /> : <Redirect href="/onboarding" />;
}

