import { Tabs } from "expo-router";
import { AppProvider } from "../src/context/AppState";
import { theme } from "../src/theme";
import TabIcon from "../src/components/TabIcon";
export default function Layout() {
  return (
    <AppProvider>
      <Tabs
        screenOptions={({ route }) => ({
          headerStyle: { backgroundColor: theme.bg },
          headerTintColor: theme.text,
          tabBarStyle: { backgroundColor: theme.card, borderTopColor: "rgba(255,255,255,0.06)", height: 64 },
          tabBarActiveTintColor: theme.primary,
          tabBarInactiveTintColor: theme.sub,
          tabBarIcon: ({ color }) => <TabIcon routeName={route.name} color={color} />,
        })}
      >
        <Tabs.Screen name="index" options={{ href: null }} />
        <Tabs.Screen name="onboarding" options={{ href: null, headerShown:false }} />
        <Tabs.Screen name="quests" options={{ title: "Quests" }} />
        <Tabs.Screen name="todos" options={{ title: "To-Dos" }} />
        <Tabs.Screen name="calendar" options={{ title: "Kalender" }} />
        <Tabs.Screen name="character" options={{ title: "Charakter" }} />
        <Tabs.Screen name="settings" options={{ title: "Settings" }} />
      </Tabs>
    </AppProvider>
  );
}
